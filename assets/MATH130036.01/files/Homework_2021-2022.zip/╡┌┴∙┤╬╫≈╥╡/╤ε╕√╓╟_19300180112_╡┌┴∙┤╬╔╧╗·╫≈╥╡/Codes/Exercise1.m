format long
N = 10000;
precise = zeros(N, 1);
for i = 1:N
    precise(i, 1) = 1/3;
end
[H, b] = Generate_Hilbert(N);
res = Conjugate_Gradient(H, b, 10^(-10));
disp(norm(res-precise, inf));