function result = Conjugate_Gradient(A, b, error)
    n = size(A, 1);
    x = ones(n, 1);
    r = b - A * x;
    p = r;
    cnt = 0;
    while true
        alpha = (r' * r)/(p' * A  * p);
        r_new = r - alpha * A * p;
        p_new = r_new + (r_new' * r_new)/(r' * r)*p;
        x_new = x + alpha * p;
        if norm(norm(r, inf)) < error
            result = x_new;
            disp(cnt)
            break
        else
            p = p_new;
            x = x_new;
            r = r_new;
            cnt = cnt + 1;
            disp(norm(r, inf));
        end
    end
    
end