function [Hil, b] = Generate_Hilbert(n)
    H = zeros(n, n);
    for row = 1:n
        for column = 1:n
            H(row, column) = 1/(row + column + 1);
        end
    end
    Hil = H;
    res = zeros(n, 1);
    for i = 1:n
        res(i, 1) = sum(H(i, :))/3;
    end
    b = res;
end