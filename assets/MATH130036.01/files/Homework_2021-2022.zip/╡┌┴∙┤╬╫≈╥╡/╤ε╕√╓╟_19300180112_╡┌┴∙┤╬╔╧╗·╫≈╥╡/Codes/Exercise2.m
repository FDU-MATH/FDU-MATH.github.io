syms x;
format long;
p = 1;
precise = zeros(1, 10);
for t = 1:10
    precise(1, 11-t) = t;
end
for i = 1:10
    p = p * (x - i);
end
coef = sym2poly(p);
ROOT = zeros(3, 10);
eps_list = [10^(-6), 10^(-8), 10^(-10)];
error = zeros(3, 10);
for i = 1:3
    p_to_solve = p + eps_list(1, i) * x^9;
    ROOT(i, :) = roots(sym2poly(p_to_solve));
    error(i, :) = ROOT(i,:) - precise;
end

