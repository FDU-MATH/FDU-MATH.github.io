function result = Generate_b(N)
    b = zeros((N+1)^2, 1);
    
    for row = 1:(N+1)
        for column = 1:(N+1)
            
            if row == 1
                b(G_Index(row, column, N), 1) = 1;
            elseif row == (N+1)
                b(G_Index(row, column, N), 1) = 1;
                
            elseif column == 1
                b(G_Index(row, column, N))= 1;
            elseif column == (N+1)
                b(G_Index(row, column, N)) = 1;
            
            
            else
                b(G_Index(row, column, N)) = (row + column)/N^3;
            end
            
            
        end
    end
    
    result = b;
end