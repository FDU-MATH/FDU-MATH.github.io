function result = Gauss_Seidel_Iteration(A, b, x_init)
    D = diag(diag(A));
    L = D - tril(A);
    U = D - triu(A);
    
    B = (D - L) \ U;
    g = (D - L) \ b;

    x_last = x_init;
    cnt = 0;
    while true
        x = B * x_last + g;
        error = x - x_last;
        if norm_2(error) < 10^(-7)
            break
        else
            x_last = x;
        end
        cnt = cnt + 1;
        disp(cnt)
    end
    
    result = x;
end