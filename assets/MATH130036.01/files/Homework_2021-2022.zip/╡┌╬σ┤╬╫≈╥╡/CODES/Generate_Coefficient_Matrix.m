function result = Generate_Coefficient_Matrix(N)
    Coeff_Matrix = zeros((N+1)^2, (N+1)^2);
    
    for row = 1:(N+1)
        for column = 1:(N+1)
            
            if row == 1
                Coeff_Matrix(G_Index(row,column,N), ...
                G_Index(row, column,N)) = 1;
            elseif row == (N+1)
                Coeff_Matrix(G_Index(row,column,N), ...
                G_Index(row, column,N)) = 1;
            
            elseif column == 1
                Coeff_Matrix(G_Index(row,column,N), ...
                G_Index(row, column,N)) = 1;
            elseif column == (N+1)
                Coeff_Matrix(G_Index(row,column,N), ... 
                G_Index(row,column,N)) = 1;
            
            
            else
                Coeff_Matrix(G_Index(row,column,N), ...
                    G_Index((row-1),column,N)) = -1;
                Coeff_Matrix(G_Index(row,column,N), ...
                    G_Index(row,(column-1),N)) = -1;
                Coeff_Matrix(G_Index(row,column,N), ...
                    G_Index(row,column,N)) = 4+(1/N^2)*exp(row*column/N^2);%这里按 i,j 从1开始
                Coeff_Matrix(G_Index(row,column,N), ...
                    G_Index((row+1),column,N)) = -1;
                Coeff_Matrix(G_Index(row,column,N), ...
                    G_Index(row,(column+1),N)) = -1;
            end
            
        end
    end
    result = Coeff_Matrix;
end