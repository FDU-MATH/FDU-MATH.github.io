function result = G_Index(row, column, N)
    result = (row-1)*(N+1)+column;
end