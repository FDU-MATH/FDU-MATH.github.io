N = 80;
t_start = cputime;
M = Generate_Coefficient_Matrix(N);
b = Generate_b(N);
x = Gauss_Seidel_Iteration(M, ...
    b, ones((N+1)^2, 1));
A = Split(x, N);
x_list = linspace(0, 1, N+1);
y_list = linspace(0, 1, N+1);
surf(x_list, y_list, A);
t_end = cputime;
disp(t_end-t_start)