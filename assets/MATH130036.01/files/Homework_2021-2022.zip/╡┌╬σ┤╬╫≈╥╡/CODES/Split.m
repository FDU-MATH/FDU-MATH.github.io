function result = Split(x, N)
    A = zeros(N+1, N+1);
    x = reshape(x, [1, (N+1)^2]);
    for row = 1:(N+1)
        A(row, 1:N+1) = x(1 , (row-1)*(N+1)+1:row*(N+1));
    end
    result = A;
end