function result = norm_2(x)
    result = sqrt(x'*x);
end