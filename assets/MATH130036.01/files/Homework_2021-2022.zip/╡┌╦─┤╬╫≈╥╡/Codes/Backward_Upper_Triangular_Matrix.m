function result = Backward_Upper_Triangular_Matrix(U, y)
    
    row_number = size(U, 1);
    column_number = size(U, 2);
    n = row_number;
    if row_number ~= column_number
        error('U is not a square matrix!')
    else
        for i = 2:n
            if U(i, 1:i-1) ~= zeros(i-1)
                error('U is not a upper triangular matrix!')
            end
        end
    end
    
    x = zeros(n, 1);
    x(n, 1) = y(n, 1)/U(n, n);
    for i = n-1:-1:1
        s = 0;
        for t = i+1:1:n
            s = s + U(i, t)*x(t, 1);
        end
        x(i, 1) = (y(i, 1) - s)/U(i,i);
    end
    result = x;
end