format long
for i = 5:1:50
    H = Hilbert(i);
    H_inverse_infty = Climbing_inf(H);
    H_inf = max(sum(abs(H), 2));
    cond_H = H_inverse_infty*H_inf;
    disp(i)
    disp(cond_H)
    disp('--------------')
end