function result = Climbing_inf(A)
    % 计算矩阵 A^{-T} 的 无穷范数.

    con = 1;
    n = size(A, 1);
    x = zeros(n, 1);
    for t = 1:n
        x(t, 1) = 1/n;
    end
    
    while con == 1
        [L, U, P] = Gauss_Elimination_Method(A', 1);
        cyc = size(x, 1);
        for i = 1:cyc
            inx = P(1, i);
            mid = x(i, 1);
            x(i, 1) = x(i+inx-1, 1);
            x(i+inx-1, 1) = mid;
        end
        y = Forward_Lower_Triangular_Matrix(L, x);
        w = Backward_Upper_Triangular_Matrix(U, y);
        v = sign(w);
        
        for i = cyc:-1:1
            inx = P(1, i);
            mid = x(i, 1);
            x(i, 1) = x(i+inx-1, 1);
            x(i+inx-1, 1) = mid;
        end

        
        [L2, U2, P2] = Gauss_Elimination_Method(A, 1);
        cyc = size(v, 1);
        for i = 1:cyc
            inx = P2(1, i);
            mid = v(i, 1);
            v(i, 1) = v(i+inx-1, 1);
            v(i+inx-1, 1) = mid;
        end
        y2 = Forward_Lower_Triangular_Matrix(L2, v);
        z = Backward_Upper_Triangular_Matrix(U2, y2);
        
        [max_value, inx] = max(abs(z));
        if max_value <= z'*x
            result = sum(abs(w));
            con = 0;
        else
            x = zeros(n, 1);
            x(inx, 1) = 1;
        end
    end
end