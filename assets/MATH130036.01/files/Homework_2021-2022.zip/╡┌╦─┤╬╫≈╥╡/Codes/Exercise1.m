format long

A = [10, -7, 0, 1;-3, 2.099999, 6, 2;5, -1, 5, -1;2, 1, 0, 2];
b = [8;5.900001;5;1];

[L_ordered, U_ordered, P_ordered] = Gauss_Elimination_Method(A, 1);
cyc = size(b, 1);
for i = 1:cyc
    inx = P_ordered(1, i);
    mid = b(i, 1);
    b(i, 1) = b(i+inx-1, 1);
    b(i+inx-1, 1) = mid;
end
y_ordered = Forward_Lower_Triangular_Matrix(L_ordered, b);
x_ordered = Backward_Upper_Triangular_Matrix(U_ordered, y_ordered);

A = [10, -7, 0, 1;-3, 2.099999, 6, 2;5, -1, 5, -1;2, 1, 0, 2];
b = [8;5.900001;5;1];
[L, U, P] = Gauss_Elimination_Method(A, 0);
for i = 1:size(b, 1)
    inx = P(1, i);
    mid = b(i, 1);
    b(i, 1) = b(i+inx-1, 1);
    b(i+inx-1, 1) = mid;
end
y = Forward_Lower_Triangular_Matrix(L, b);
x = Backward_Upper_Triangular_Matrix(U, y);