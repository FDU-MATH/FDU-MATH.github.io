format long
estimation = zeros(26, 1);
real_estimation = zeros(26, 1);

for t = 5 : 30
    A = Generate_An(t);
    precise_solution = randn(t, 1);
    b = A*precise_solution;
    b_infty = max(abs(b));
    
    [L, U, P] = Gauss_Elimination_Method(A, 1);
    for i = 1:t
        inx = P(1, i);
        mid = b(i, 1);
        b(i, 1) = b(i+inx-1, 1);
        b(i+inx-1, 1) = mid;
    end
    y = Forward_Lower_Triangular_Matrix(L, b);
    x = Backward_Upper_Triangular_Matrix(U, y);
    
    r = b - A*x;
    r_infty = max(abs(r));
    
    A_inverse_infty = Climbing_inf(A);
    A_infty = max(sum(abs(A), 2));
    cond_A = A_inverse_infty*A_infty;
    
    estimation(t-4, 1) = cond_A * r_infty / b_infty;
    real_estimation(t-4, 1) = max(abs(x - precise_solution)) / ...
        max(abs(precise_solution));
end