function result = Forward_Lower_Triangular_Matrix(L, b)

    row_number = size(L, 1);
    column_number = size(L, 2);
    n = row_number;
    if row_number ~= column_number
        error('L is not a square matrix!')
    else
        for i = 1:n-1
            if L(i, i+1:n) ~= zeros(n-i)
                error('L is not a lower triangular matrix!')
            end
        end
    end
    
    y = zeros(n, 1);
    y(1,1) = b(1, 1)/L(1, 1);
    for i = 2:1:n
        s = 0;
        for t = 1:1:i-1
            s = s + L(i, t)*y(t, 1);
        end
        y(i, 1) = (b(i, 1) - s)/L(i,i);
    end
    result = y;
end