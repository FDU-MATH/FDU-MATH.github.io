function [L, U, P] = Gauss_Elimination_Method(A, ordered)

    row_number = size(A, 1);
    column_number = size(A, 2);
    if row_number ~= column_number
        error('A is not a square matrix!')
    end
    P = zeros(1, row_number);
    P(1, row_number) = 1;
    for i = 1 : row_number-1
        [m, inx_i] = max(abs(A(i:row_number, i)));
        if m == 0
            error('det(A) = 0!')
        else
            if ordered == 1
                P(1, i) = inx_i;
                inx_i = inx_i + i-1;
                if inx_i ~= i
                    mid = A(inx_i, :);
                    A(inx_i, :) = A(i, :);
                    A(i, :) = mid;
                end
            else
                P(1, i) = 1;
            end
            
            for t = i+1 : row_number
                coef = A(t, i) / A(i, i);
                A(t, i+1:row_number) = (A(t,i+1:row_number) - ...
                    coef * A(i, i+1:row_number));
                A(t, i) = coef;
            end
        end
    end
    
    L = eye(row_number);
    U = zeros(row_number, row_number);
    for t = 2:row_number
       L(t, 1:t-1) = A(t, 1:t-1);
    end
    for t = 1:row_number
        U(t, t:row_number) = A(t, t:row_number);
    end
end