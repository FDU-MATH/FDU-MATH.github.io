x = linspace(1.9, 2.1, 10000);

y2 = [];

tic
for i = x
    y2 = [y2, (i - 2)^9];
end
toc

plot(x, y2, 'b')
axis([1.99 2.01 -5*10^(-11) 5*10^(-11)])