%习题1
format long

%使用 roots 函数进行求解
P = [1, -1000, 1];

tic
a = roots(P);
toc 

disp(a)


%1.直接使用求根公式进行求解
tic
x1_formula = (1000 + sqrt(1000^2 - 4))/2;
x2_formula = (1000 - sqrt(1000^2 - 4))/2;
toc

disp(x1_formula)
disp(x2_formula)

% 计算两个方法得到结果之间差距
disp(abs(999.9989999990000 - 999.9989999989999))
disp(abs(0.001000001000023 - 0.000010000010000))

% 计算
disp(sqrt(1000^2 - 4))


%由两根间关系进行求解--Relation1
tic
x1_relation1 = (1000 + sqrt(1000^2 - 4))/2;
x2_relation1 = 1 / x1_relation1;
toc

disp(x1_relation1)
disp(x2_relation1)

%由两根间关系进行求解--Relation2
tic
x2_relation2 = (1000 - sqrt(1000^2 - 4))/2;
x1_relation2 = 1/ x2_relation2;
toc

disp(x1_relation2)
disp(x2_relation2)

%计算解之间的差距
x1 = 999.9989999989999;
x2 = 0.000010000010000;

disp(abs(x1 - x1_relation1))
disp(abs(x2 - x2_relation1))
disp(abs(x1 - x1_relation2))
disp(abs(x2 - x2_relation2))


%使用迭代法
y1 = 490; %初始化一个较大的值, 以获取较大根
error = 10; %初始化一个较大的误差

tic
while error > 0.00000001
    error  = 0.5*((249999/y1) - y1);
    y1 = y1 + error;
end
toc

x1_iteration = y1 + 500;
disp(y1 + 500)

%使用迭代法
y2 = -499.9; %初始化一个较小的值, 以获取较小根
error = 10; %初始化一个较大的误差

tic
while error > 0.00000001
    error  = 0.5*((249999/y2) - y2);
    y2 = y2 + error;
end
toc

x2_iteration = y2 + 500;
disp(y2 + 500)

%计算解之间差距
disp(abs(x1-x1_iteration))
disp(abs(x2-x2_iteration))