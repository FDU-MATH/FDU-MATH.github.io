%习题2 方法2

x_list = linspace(0.00000001, 0.001, 100000);
y_list2 = [];

for i = x_list
    t = exp(i);
    
    if i < 0.0000001
        disp([i, t])
    end
    
    y_list2 = [y_list2, (t-1)/log(t)];
end

plot(x_list, y_list2, 'r');