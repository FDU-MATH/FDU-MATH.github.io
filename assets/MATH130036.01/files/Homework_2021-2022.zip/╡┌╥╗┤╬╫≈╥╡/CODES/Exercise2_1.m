%习题2 方法1

x_list = linspace(0.00000001, 0.001, 100000);
y_list = [];

for i = x_list

    if i < 0.0000001
        disp([i (exp(i)-1)/i])
    end
    
    y_list = [y_list, (exp(i)-1)/i];
end

plot(x_list, y_list);
axis([0 0.001 1 1.0006])