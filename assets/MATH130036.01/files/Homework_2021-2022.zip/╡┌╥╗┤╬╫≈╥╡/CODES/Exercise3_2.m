%习题3

% 直接使用展开式
x_list = linspace(1.9, 2.1, 100000);

y0 = [];

tic
for x = x_list
    y0 = [y0, x^9 - 18*x^8 + 144*x^7 - 672*x^6 + 2016*x^5 - 4032*x^4 + 5376*x^3 - 4608*x^2 + 2304*x - 512];
end
toc

plot(x_list, y0, 'g')