%习题2 简单分析
% 此程序中的 x_list y_list y_list2 就为 Exercise2_1.m, Exercise2_2.m 中对应
% 向量. 要正确运行此程序, 需要先将 x_list y_list y_list2 导入工作区.

plot(x_list, y_list-y_list2, 'b')
hold on;
plot(x_list, y_list-1,'o')
hold on;
plot(x_list, y_list2-1,'p')
axis([0 0.000001 -0.00000002 0.0000001])
legend('两种方法得到值之差','方法1得到的值','方法2得到的值')