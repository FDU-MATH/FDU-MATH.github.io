%习题3

% 使用 (x-2)^9
x = linspace(1.9, 2.1, 100000);

y2 = [];

tic
for i = x
    y2 = [y2, (i - 2)^9];
end
toc

plot(x, y2, 'b')