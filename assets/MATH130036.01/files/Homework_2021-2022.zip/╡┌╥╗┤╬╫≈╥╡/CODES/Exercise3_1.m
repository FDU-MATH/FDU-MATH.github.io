%习题3

%获得展开式
syms x
fx = (x - 2)^9;
expand(fx)