function result = Compound_Trapezoidal_Formula(N, a, b, f)
    % N: integer.
    % a: a real number.
    % b: a real number. 
    % b > a.
    % f: a function about x(syms).
    % 对 f 在 [a, b] 使用复合梯形公式求积.
    % 此处将区间 [a, b] 等距划分成 N 段.
    syms x
    
    x_list = linspace(a, b, N+1);
    y_list = eval(subs(f, x, x_list));
    
    INT = y_list(1);
    for i = 2 : 1 : N
       INT = INT + (2*y_list(i));
    end
    INT = INT + y_list(N+1);
    INT = INT * ((b-a)/(2*N));
    
    result = INT;
end