function result = Richardson_Extrapolation_Method(value_1, value_2, i)
    % 这里对 T(n) = n\sin(pi/n)  = 
    %                    sum_{i=0}^{\infty} \frac{pi^{2i+1}}{(2i+1)! n^{2i}}
    % 使用 Richardson 外推算法.
    % 这里 value_1 代表某个 T(n), value_2 代表 T(2n).
    % i 代表对 n^{-i} 进行操作.
    
    result = (value_2 - (value_1/2^(i))) * (1/(1-1/2^(i)));
end