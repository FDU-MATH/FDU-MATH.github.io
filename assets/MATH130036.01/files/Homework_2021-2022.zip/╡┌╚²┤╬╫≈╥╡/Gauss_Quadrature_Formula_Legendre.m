function result = Gauss_Quadrature_Formula_Legendre(N, f)
    % N: integer.
    % a: a real number.
    % b: a real number. 
    % b > a.
    % f: a function about x(syms).
    % 对 f 带权 1 在 [-1, 1] 使用 Gauss 求积公式.
    syms x

    zero_dots = zeros(1, N);
    v = 1 - 1/(8*(N^2)) + 1/(8*(N^3));
    for k = 1:N
        zero_dots(k) = v * cos(pi * (((4*k)-1) / ((4*N)+2)));
    end
        
    Eff = zeros(N,N);
    b = zeros(N, 1);
    for i = 1:N
        Eff(i,:) = zero_dots.^(i-1);
        b(i,1) = int(x^(i-1), -1, 1);
    end
    
    A = Eff\b;
    F = subs(f, x, zero_dots);
    result = F*A;
       
end