do_list = [2, 4, 6, 8, 10, 20, 40, 60, 80, 100];

syms x;
format long;
Legendre_Plot(10)
Trapezoidal = zeros(1, 10);
Simpson = zeros(1, 10);
Gauss = zeros(1, 10);
for N = 1:10
    Trapezoidal(N) = Compound_Trapezoidal_Formula(do_list(N), 0, 1, sin(x));
    Simpson(N) = Compound_Simpson_Formula(do_list(N), 0, 1, sin(x));
    Gauss(N) = Gauss_Quadrature_Formula_Legendre(do_list(N), abs(sin(x)))/2;
end


disp(eval(int(sin(x), 0, 1)));