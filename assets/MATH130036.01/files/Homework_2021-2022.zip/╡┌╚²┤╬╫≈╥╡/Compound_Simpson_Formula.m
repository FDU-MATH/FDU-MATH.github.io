function result = Compound_Simpson_Formula(N, a, b, f)
    % N: integer.
    % a: a real number.
    % b: a real number. 
    % b > a.
    % f: a function about x(syms).
    % 对 f 在 [a, b] 使用复合辛普森公式求积.
    
    syms x
    
    x_list = linspace(a, b, N+1);
    y_list = eval(subs(f, x, x_list));
    x_list_mid = zeros(1, N);
    for i = 1 : N
        x_list_mid(i) = (x_list(i) + x_list(i+1))/2;
    end
    y_list_mid = eval(subs(f, x, x_list_mid));
    
    INT = y_list(1);
    for t = 2 : 1 : N
       INT = INT + 2*y_list(t);
    end
    for s = y_list_mid
       INT = INT + 4*s; 
    end
    INT = INT + y_list(N+1);
    INT = INT * ((b-a)/(6*N));
    
    result = INT;
end