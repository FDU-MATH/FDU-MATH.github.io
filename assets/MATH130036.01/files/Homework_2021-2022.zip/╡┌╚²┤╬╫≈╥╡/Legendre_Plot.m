function Legendre_Plot(N)
    % 绘制零点所处图像
    
    x_list = linspace(-1,1,1000);
    syms x
    
    % 获取 N 阶 Legendre 多项式
    L_N  = (x^2 - 1)^N;
    for i = 1:N
       L_N = diff(L_N); 
    end
    L_N = L_N/(2^N * factorial(N));
    
    % 获取近似零点
    zero_dots = zeros(1, N);
    v = 1 - 1/(8*(N^2)) + 1/(8*(N^3));
    for k = 1:N
        zero_dots(k) = v * cos(pi * (((4*k)-1) / ((4*N)+2)));
    end
    
    y_list = eval(subs(L_N, x, x_list));
    value_zeros = eval(subs(L_N, x, zero_dots));
    scatter(zero_dots, value_zeros);
    hold on;
    plot(x_list, y_list);

    
    
end