Value_n_3 = 3 * sin(pi/3);
Value_n_6 = 6 * sin(pi/6);
Value_n_12 = 12 * sin(pi/12);

S_1 = Richardson_Extrapolation_Method(Value_n_3, Value_n_6, 2);
S_2 = Richardson_Extrapolation_Method(Value_n_6, Value_n_12, 2);

answer = Richardson_Extrapolation_Method(S_1, S_2, 4);


