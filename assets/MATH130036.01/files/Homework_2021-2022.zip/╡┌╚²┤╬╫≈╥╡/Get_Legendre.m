function result = Get_Legendre(N)
    syms x
    Legendre_N = (x^2 - 1)^(N);
    for i = 1:N
       Legendre_N = diff(Legendre_N); 
    end
    
    result = expand(Legendre_N);
end