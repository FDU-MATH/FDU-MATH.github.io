import re
import torch
import pandas as pd
import re
with open('10.csv') as f:
    a = f.read()
a = a.replace('E', 'e')
a = a.split(',')
print(a)
def add(x):
    res = torch.zeros_like(x)
    for t in range(len(a)):
        func = lambda x : float(a[t])*x**(len(a)-t)
        for j in range(len(x)):
            res[j] += func(x[j])
    return res
# print(add(torch.linspace(-1,1,2)))