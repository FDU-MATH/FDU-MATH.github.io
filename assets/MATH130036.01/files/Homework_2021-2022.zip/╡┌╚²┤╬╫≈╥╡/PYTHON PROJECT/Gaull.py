imoprt SymPy
import scipy