import math

import torch
import math
import add
func = lambda x:(x-1.1651616556)**2
x_list = torch.linspace(-3, 3, 2)
mid = 100000
lr = 0.0001
cnt = 0
while True:
    x_list.requires_grad_(True)
    y_list = func(x_list)
    x_list.cuda()
    y_list.cuda()
    y_list.requires_grad_(True)

    loss = pow(y_list, 2)
    loss.cuda()
    loss.backward(torch.ones_like(x_list))
    print(sum(loss))
    with torch.no_grad():
        x_list = x_list - lr * x_list.grad

    print(sum(loss),'\t', cnt)
    cnt += 1
    if abs(mid - sum(loss)) < 0.0000000000001:
        break
    else:
        mid = sum(loss)
print(x_list)