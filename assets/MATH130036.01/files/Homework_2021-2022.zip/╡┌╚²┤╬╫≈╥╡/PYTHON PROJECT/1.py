import re
import torch
import pandas as pd
import re
with open('10.csv') as f:
    a = f.read()
print(a)
a = a.replace('E', 'e')
a = a.split(',')
def add(x):
    res = [0 for i in x]
    for t in range(len(a)):
        func = lambda x : float(a[t])*x**(len(a)-t)
        for j in range(len(x)):
            res[j] += func(x[j])
    return res
print(add(torch.linspace(-1,1,2)))