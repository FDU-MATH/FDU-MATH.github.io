% 运行此程序前请先将 Exercise1_2.m 的变量导入工作区.

plot(x_list2, y2, 'r')
hold on;
plot(x_list2, y4, 'g')

axis([-0.05 0.05 -0.5 1.5])