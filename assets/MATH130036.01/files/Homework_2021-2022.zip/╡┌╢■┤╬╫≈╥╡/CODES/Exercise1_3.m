% 计算 Lagrange 插值函数 n = 10
x_list = linspace(-1,1,20);
y1 = 1./(1+25*(x_list.^2));
syms x
func_Lagrange_2 = expand(Lagrange_interpolation(x_list, y1));
disp(func_Lagrange_2)

% 绘图
x_list = linspace(-1,1,20); % 用于插值的结点
x_list2 = linspace(-1,1,1000); % 用于绘图的结点
y1 = 1./(1+25*(x_list.^2)); % 用于插值的结点
y2 = 1./(1+25*(x_list2.^2)); % 用于绘图的结点

y3 = subs(func_Lagrange_2,x,x_list2); % Lagrange 插值
y4 = spline(x_list, y1, x_list2);

plot(x_list, y1, 'o')
hold on;
plot(x_list2, y2, 'r')
hold on;
plot(x_list2, y3, 'b')
hold on;
plot(x_list2, y4, 'g')

for i = 1:19
   x_list_i = linspace(x_list(1,i),x_list(1,i+1),100);
   y_list_i = subs(cubic_spline_interpolation(x_list, y1, 25/338, 25/338,i), x, x_list_i);
   plot(x_list_i, y_list_i,'k');
   hold on;
end

legend({'插值结点', '原函数 f(x)', 'Lagrange 插值函数', '三次样条插值函数(MATLAB)','三次样条插值函数(SELF)'}, 'Location','northoutside')
title('n = 20')