x_list2 = linspace(-1,1,1000); % 用于绘图的结点
x_list = -1:0.2:1;
y1 = 1./(1+25*(x_list2.^2)); % 用于绘图的结点
y2 = 1./(1+25*(x_list.^2));
syms x
func = 1/72057594037927936*x^3 - 394/685*x^2 - 1/24019198012642644*x + 1845/3811;
y3 = subs(func, x, x_list2);
plot(x_list2, y1);
hold on;
plot(x_list, y2,'o');
hold on;
plot(x_list2, y3)