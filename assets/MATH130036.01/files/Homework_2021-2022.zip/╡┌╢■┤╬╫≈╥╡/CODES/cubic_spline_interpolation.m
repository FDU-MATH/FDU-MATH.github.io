function result = cubic_spline_interpolation(x_list, y_list, df_1, df_n, t)
    % 三次样条插值
    % x_list 为插值结点, y_list 为对应的函数值. result 返回对应的多项式.
    % df_0 最左端一阶导数值, df_n 最右端一阶导数值.
    % t 表示输出第几段上的样条函数.
    % x_list 应从小到大排列.
    % 这里边界条件为给定两端的一阶导数值.
    
    syms x
    n = size(x_list, 2);
    
    Coeff = zeros(n, n); % 系数矩阵
    Value = zeros(n, 1); % 值的列向量
    
    lambda_1 = 1;
    f_12 = ((y_list(1,2) - y_list(1,1))/(x_list(1,2) - x_list(1,1)));
    d_1 = (6/(x_list(1,2) - x_list(1,1))) * (f_12 - df_1);
    mid = zeros(1, n);
    mid(1,1) = 2;
    mid(1,2) = lambda_1;
    Coeff(1, 1 : n) = mid;
    Value(1,1) = d_1;
    
    for i = 2 : n - 1
        h_i = x_list(1,i+1) - x_list(1,i);
        h_i_minus = x_list(1,i) - x_list(1,i-1);
        mu_i = h_i_minus / (h_i + h_i_minus);
        lambda_i =  1 - mu_i;
        f_i_iplus = ((y_list(1,i+1) - y_list(1,i))/(x_list(1,i+1) - x_list(1,i)));
        f_iminus_i = ((y_list(1,i) - y_list(1,i-1))/(x_list(1,i) - x_list(1,i-1)));
        d_i = 6 * (f_i_iplus - f_iminus_i) / (h_i_minus + h_i);
        mid_i = zeros(1, n);
        mid_i(1,i-1) = mu_i;
        mid_i(1,i) = 2;
        mid_i(1,i+1) = lambda_i;
        Coeff(i, 1:n) = mid_i;
        Value(i, 1) = d_i;
    end

    mu_n = 1;
    h_n_minus = x_list(1,n) - x_list(1,n-1);
    f_nminus_n = ((y_list(1,n) - y_list(1,n-1))/(x_list(1,n) - x_list(1,n-1)));
    d_n = 6/h_n_minus * (df_n - f_nminus_n);
    mid_n = zeros(1, n);
    mid_n(1,n) = 2;
    mid_n(1,n-1) = mu_n;
    Coeff(n, 1 : n) = mid_n;
    Value(n,1) = d_n;
    
    
    
    M = linsolve(Coeff, Value);
    
    
    
    syms x
    poly_cell = cell(n-1,1);
    for i = 1 : n-1
        h_i = x_list(1,i+1) - x_list(1,i);
        S_i_1 = M(i, 1) * ((x_list(1,i+1) - x)^3)/(6*h_i);
        S_i_2 = M(i+1, 1) * ((x - x_list(1,i))^3)/(6*h_i);
        S_i_3 = (y_list(1, i) - (M(i, 1) * (h_i^2))/6) * (x_list(1,i+1) - x)/h_i;
        S_i_4 = (y_list(1, i+1) - (M(i+1, 1) * (h_i^2))/6) * (x - x_list(1,i))/h_i;
        S_i = S_i_1 + S_i_2 + S_i_3 + S_i_4;
        poly_cell{i,1} = expand(S_i);
    end
    
    result = poly_cell{t,1};
end