syms x
func = 1/(1+25*x^2);
df = diff(func, x);
disp([subs(df, x, -1), subs(df, x, -1)])

x_list_spline = linspace(-1,1,10);
y_list_spline = subs(func, x, x_list_spline);
for i = 1:9
    disp(num2str(i))
    cubic_spline_interpolation(x_list_spline, y_list_spline, 25/338,25/338,i)
end
