format rat
x_list = -1:0.2:1;

b = [];
for i = x_list
    b = [b; 1/(1+25*i*i)];
end

A_cell = cell(11, 1);
for t = 1:size(x_list, 2)
    s = x_list(t);
    A_cell{t,1} = [1 s s^2 s^3];
end

A = [];
for p = 1:11
    A = [A;A_cell{p,1}];
end

A_trans = transpose(A);

x = inv(A_trans*A) * A_trans * b;
disp(x)