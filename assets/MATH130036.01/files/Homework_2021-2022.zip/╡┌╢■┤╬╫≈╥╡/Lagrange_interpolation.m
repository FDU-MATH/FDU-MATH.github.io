function result = Lagrange_interpolation(x_list, y_list)
%   Lagrange 插值
%   这里 x_list 为插值结点, y_list 为对应的函数值, result 返回对应的多项式
    
    n = size(x_list, 2); % 这里获取插值点个数
    
    syms x
    A = cell(n, 1);
    
    w = 1;
    for i = 1:n
       w = w*(x - x_list(i));
    end
    
    for j = 1:n
        w_final = w/(x - x_list(j));
        w_final_value = subs(w_final, x, x_list(j));
        mid = (w_final/w_final_value)*y_list(j);
        A{j,1} = mid;
    end
       
    poly = 0;
    for t = 1:n
       poly = poly + A{t,1};
    end
    
    result = poly;
end

